
v1=[0 0 0]; v2=[0 1 0]; pt=[1 2 0];

d = point_to_line(pt, v1, v2)
