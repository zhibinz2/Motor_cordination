%% dot and line
v1=[0 0];
v2=[1 1];
pt=[1 0];% [xJ,yJ];

distance=point_to_line_distance(pt, v1, v2)

sqrt(0.5)

%% two dots
X = [0,0;2,1];
d = pdist(X,'euclidean')

x = [0 0];y = [2 1];
norm(x-y)

x = [0 0];y = [2 1];
norm(x-y)

sqrt(5)

sumsqr([3 4])

rssq([3 4])