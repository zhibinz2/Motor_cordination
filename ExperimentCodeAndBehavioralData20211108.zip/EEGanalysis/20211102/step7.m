% pick the behaviorally good trials
TrialScores
