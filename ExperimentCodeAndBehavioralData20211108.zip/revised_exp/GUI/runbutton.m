function runbutton(obj,eventdata,h)
   
    set(h.hEdt1,'Enable','inactive');
    set(h.hEdt2,'Enable','inactive');
    set(h.hEdt3,'Enable','inactive');
    set(h.hPB,'Enable','off');
    set(h.hText,'String','Please wait');

end