%% load behaviral data
clear;
cd('/home/zhibin/Documents/Acquisition/zhibin20210901')
load('matlab20210901.mat');

%% Reorgainize behavioral data into BehavData and condition
subjectnumber=data.subjectnumber;
dataBlock=data.dataBlock;
dataTrialL=dataBlock.dataTrialL;
dataTrialR=dataBlock.dataTrialR;
blockNumber=dataBlock.blockNumber;
xLyL=dataTrialL.xLyL;
condition=dataTrialL.condition;

numBlock=length(dataBlock);
BehavData={};
CondiData=[]; 

for b=1:numBlock
    for t=1:length(data.dataBlock(b).dataTrialL)
        dataxLyLtemp=data.dataBlock(b).dataTrialL(t).xLyL;
        dataxRyRtemp=data.dataBlock(b).dataTrialR(t).xRyR;
        dataxLyLxRyRtemp=[dataxLyLtemp dataxRyRtemp];
        dataConditiontemp=data.dataBlock(b).dataTrialL(t).condition;
        BehavData=[BehavData; {dataxLyLxRyRtemp}];
        CondiData=[CondiData; dataConditiontemp];
    end
end

% ans=BehavData{1};
% CondiData

NumTrialsRecorded=length(CondiData);


%% Check EEG on 20210901
% load EEG separately
dataEEG=[];datatimes=0;dataEEGtemp=[];datatimestemp=[];
for block=1:4
    EEG=loadcurry([pwd '/bimanual_circle_score_forward_backward_20210901_block' num2str(block) '.cdt']);
    dataEEGtemp=EEG.data;
    datatimestemp=EEG.times;
    dataEEG=[dataEEG dataEEGtemp];
    datatimes=[datatimes datatimes(end)+0.5+datatimestemp];
end
datatimes(1)=[];

% plot(datatimes);
% find(hist(datatimes,unique(datatimes))>1)

% load EEG all as one
% EEG=loadcurry([pwd '/bimanual_circle_score_forward_backward_20210901_block1.cdt']);
% dataEEG=EEG.data;
% datatimes=EEG.times;

Fs=EEG.srate;
% plot(datatimes,dataEEG);

% plot photocell analog signal
analog1=133; %analog2=134;trigger=139;
analog1data=dataEEG(133,:);
% analog2data=dataEEG(134,:);
% plot(datatimes,analog1data);
% plot(datatimes,analog2data);
% close all
Halfhigh1=1/2*(max(analog1data)-min(analog1data));
% Halfhigh2=1/2*(max(analog2data)-min(analog2data));

% locate the trial sessions % pks=value of the peak % locs=time of the peak
% findpeaks(analog1data,datatimes,'MinPeakProminence',Halfhigh1,'Annotate','extents');
% indcutoff=find(datatimes==2055998.5);
% datatimes(indcutoff:end)=[];
% analog1data(indcutoff:end)=[];
% analog1data(:,indcutoff:end)=[];
[pks,locs] = findpeaks(analog1data,datatimes,'MinPeakProminence',Halfhigh1,'Annotate','extents');


%*************************** all data

locsDiff=diff(locs);% time distances between peaks
% plot(locsDiff,'ro');% look at distribution of these distances
ind_locsDiff=find([locsDiff, inf]>5*mean(locsDiff)); % pks distance indices at the end of each trial 
trialLength=diff([0 ind_locsDiff]); %number of peaks in each trial
% plot(trialLength,'ro') % look at trial length
ind_trial_end=cumsum(trialLength); % ending peak of each trial (index in locs)
ind_trial_start=ind_trial_end-trialLength+1;

% ind_trial_start=zeros(1,NumTrialsRecorded);
% for ntr=1:NumTrialsRecorded
%     ind_trial_start(ntr)=ind_trial_end(ntr)-trialLength(ntr)+1;
% end


% starting peak of the trials (index in locs)
% plot(ind_trial_start,zeros(length(ind_trial_start)),'go'); 
% hold on;
% plot(ind_trial_end,ones(length(ind_trial_end)),'ro');

%*****************************
%% detrend the data

addpath(genpath('/home/zhibin/Documents/GitHub'));
% data=dataEEG(1:128,2000000:2002000);
data=dataEEG(1:128,:);

% tranpose the data so that time is the first dimension, channel is 2nd dimension, and trial is the 3rd dimension
transpose_data=permute(data,[2,1]);
% transpose_data=permute(data_trials,[3,2,1]);
% transpose_data=transpose_data(:,1:128);
% transpose_data=transpose_data(:,1:128,:);
% plotx(mean(transpose_data,3));
% plotx(transpose_data);

% detrend the data
detrend_data=ndetrend(transpose_data,1); 
% plotx(mean(detrend_data,3));
% plotx(detrend_data);


%% Broadband filter
% apply high pass filter to filter out frequencies lower than 1;
% load eeglab toolbox to avoid filtered_data becoming NaN
eeglab;
close all;
Hd = makefilter(2000,1,0.5,3,20,0); % Astop 6 or 20;
filtered_data=filtfilthd(Hd,double(detrend_data));

% remove channel 91 44
% filtered_data(:,91)=[];filtered_data(:,44)=[];
%  plotx(filtered_data);

% apply low pass filter to filter out frequencies higher than 50;
Hd = makefilter(2000,50,55,3,20,0);
filtered_data=filtfilthd(Hd,filtered_data);

% plotx(mean(filtered_data,3));
% plotx(filtered_data);
%% fiter5bands results
% load('fitered_data5bands.mat');

% filtered_data=filtered_delta;
% filtered_data=filtered_theta;
% filtered_data=filtered_alpha;
% filtered_data=filtered_beta;
% filtered_data=filtered_gamma;

% plot(filtered_beta(5000:10000,8));
% figure;
% plot(filtered_gamma(5000:10000,8));
%% organize filtered_data into data_trials=sample_timepoints x (139+4 channels) x  trial  
% Fs=2000;ifi=0.0167;
NumTrialsRecorded=length(ind_trial_start);
NumTrialtimepoints=round(max(trialLength)*2*ifi*Fs);%number of samples in a trial,ideally
NumEEGChannels=size(filtered_data,2);
NumAllChannels=NumEEGChannels+4;

% zeros at the end of the trial session if trials shorter than is should
% be, ideally
% Reality is, sometimes this trial length do not cover the length of some
% trial
data_trials=zeros(NumTrialtimepoints,NumAllChannels,NumTrialsRecorded);
% CondiData

trialstart=zeros(1,NumTrialsRecorded);trialend=zeros(1,NumTrialsRecorded);
% timing (trial length) might mess up
for ntr=1:NumTrialsRecorded % take too much memory, matlab might quit
    trialstart(ntr)=find(datatimes==locs(ind_trial_start(ntr)));
    trialend(ntr)  =find(datatimes==locs(ind_trial_end(ntr)));
    data_trials(1:(trialend(ntr)-trialstart(ntr)+1),1:NumEEGChannels,ntr)=filtered_data(trialstart(ntr):trialend(ntr),1:NumEEGChannels); 
end

% examine 
% plot(ind_trial_end-ind_trial_start,'ro');ylabel('trial peaks');xlabel('trial');
% locsstart=locs(ind_trial_start);
% locsend=locs(ind_trial_end);
% plot(trialend-trialstart,'ro');ylabel('trial length');xlabel('trial');
% plot(trialstart,ones(1,length(trialstart)),'go');hold on;plot(trialend,ones(1,length(trialend)),'ro'); % check 1 second inter-trial interval
% plot(data_trials(:,1:128,5));
% plot(datatimes)

%% Resample BehavData
RSBehavData={};
% block=1;
% for ntr=NumTrialsRecorded*(block-1)+1:NumTrialsRecorded*(block-1)+NumTrialsRecorded
for ntr=1:NumTrialsRecorded
    xLyLxRyRtemp=BehavData{ntr};
    shift=xLyLxRyRtemp(1,:); % shift to the origin (start from zero to minimized edge artifact)
    xLyLxRyRtempshift=xLyLxRyRtemp-shift.*ones(size(xLyLxRyRtemp,1),1);
    
    padstart=xLyLxRyRtempshift(1,:).*ones(size(xLyLxRyRtempshift,1),1); % padding before the start of trial
    padtend=xLyLxRyRtempshift(end,:).*ones(size(xLyLxRyRtempshift,1),1); % padding after
    xLyLxRyRtempshiftpad=[padstart;xLyLxRyRtempshift;padtend]; % concatenate
    RSxLyLxRyRtempshiftpad=resample(xLyLxRyRtempshiftpad,size(data_trials,1),length(xLyLxRyRtemp)); % resample
    RSxLyLxRyRtempshift=RSxLyLxRyRtempshiftpad(size(data_trials,1)+1:2*size(data_trials,1),:);% remove the padding
    RSxLyLxRyRtemp=RSxLyLxRyRtempshift+shift.*ones(size(RSxLyLxRyRtempshift,1),1); % shift back to the original position
    
    RSxLyLxRyRtemp=RSxLyLxRyRtemp'; % transpose to fit into trial EEG matrix
    RSBehavData{ntr}={RSxLyLxRyRtemp};
end

% % examine RSBehavData
% ans=RSBehavData{1};
% ans=RSBehavData{51};

%% integrate BehavData and CondiData into data_trials: trials x (139+4 channels) x sample_timepoints;

% for ntr=NumTrialsRecorded*(block-1)+1:NumTrialsRecorded*(block-1)+NumTrialsRecorded
for ntr=1:NumTrialsRecorded
    data_trials(:,NumEEGChannels+1:NumEEGChannels+4,ntr)=[cell2mat(RSBehavData{ntr})]'; % replace the last four channels
end

% % Just to check out
% CondiData;
% figure;plot(CondiData);
% unique(CondiData)
% allPerm;
% conditionfuctions;
conditionNames={'A1&A2','A1&A1','A2&A1','A2&A2'};
% conditionNames{1};
%% Integrate 

%% draw condition trace
addpath Bimanual
addpath DrawSquares
addpath DrawCurves

% plot the mouse trace
UniCondi=unique(CondiData);

for u=1:length(UniCondi)% u=2
    
    indtemp=find(CondiData==UniCondi(u));
    
    [xL,yL,PosL,PosL0,PosL1,PosL2,PosL3,ThicknessL,ColorL,...
    xR,yR,PosR,PosR0,PosR1,PosR2,PosR3,ThicknessR,ColorR] ...
    = conditionfuctions{UniCondi(u)}(steplength,yCenter,screenXpixels);
    
    subplot(1,length(UniCondi),u);
    
    plot(PosL(1,:),PosL(2,:),'-g', 'LineWidth',10);
    hold on;
    plot(PosR(1,:),PosR(2,:),'-g','LineWidth',10); 
    hold on;
    
    for indt=1:length(indtemp)
    TracexL=squeeze(data_trials(:,NumEEGChannels+1,indtemp(indt)));
    TraceyL=squeeze(data_trials(:,NumEEGChannels+2,indtemp(indt)));
    TracexR=squeeze(data_trials(:,NumEEGChannels+3,indtemp(indt)));
    TraceyR=squeeze(data_trials(:,NumEEGChannels+4,indtemp(indt)));
    plot(TracexL,TraceyL,'-r',TracexR,TraceyR,'-b');
    end
    
    set(gca, 'YDir', 'reverse');
    hold off;
    
    xlim([0 screenXpixels]);ylim([0 screenYpixels]);
    title(['condition' conditionNames{UniCondi(u)}]);
  
end

%% take a look at the EEG
plotx(data_trials(:,1:128,2));
EEG_trial1=squeeze(data_trials(:,1:128,50));
EEG_trial1mean=mean(EEG_trial1,2).*ones(1,128);
EEG_trial1=EEG_trial1-EEG_trial1mean;
plotx(EEG_trial1);

%% clean artifact
filtered_data=data_trials(:,1:128,:);

threshold=60; % set a amplitude threshold as criteria to remove bad channels and epochs later

% set good standard percentages
prctepoch = 70; % percentage of epochs that should be good
prctchan = 70; % percentage of channels that should be good

% set bad standard percentage
cirtepoch =  1-prctepoch/100; % the percentage of bad epochs allowed
critchan = 1-prctchan/100; % the percentage of bad channels allowed

nSamps = size(filtered_data,1);
nChans = size(filtered_data,2);
nEpochs = size(filtered_data,3);

 % find the the empty channels
sumovertime=sum(filtered_data,1);
sumovertrials=sum(sumovertime,3);
zerochans = find(sumovertrials== 0);

% design a matrix with highest value for each channel on each trial(each single channel in each epoch). 
trialdatamax = squeeze(max(abs(filtered_data),[],1));  
% examine the maximal abs trial matrix
% imagesc(trialdatamax);colorbar;ylabel('chan');xlabel('trial');

% create a bad channel list containing the last 4 channels to be removed
badchans = [129 130 131 132]; 

% initiate a good channel list by removing the badchans
goodchans = setdiff(1:nChans,badchans); 

% create the bad trials matrix
trialpass = zeros(size(trialdatamax));
trialpass(find(trialdatamax > threshold)) = 1;   % locates the 1 (bad), i.e. the bad trials
% examine the bad trials
% imagesc(trialpass);colorbar;

% find the bad epochs/trials
trialpass = sum(trialpass(goodchans,:),1)/length(goodchans); % the percentage of bad channels on each epoch
badepochs = find(trialpass > cirtepoch);  %determines if an epoch has too many of the bad channels. 

% create a good epoch list 
goodepochs = setdiff(1:nEpochs,badepochs);

% create the bad trials matrix again
chanpass = zeros(size(trialdatamax)); % create the bad trial matrix
chanpass(find(trialdatamax >threshold)) = 1; %locates the 1 (bad), i.e.bad trials
% examine the bad channel matrix
% imagesc(chanpass);colorbar;

% find the bad channels
chanpass = sum(chanpass(:,goodepochs),2)/length(goodepochs); % the percentage of bad epochs in each channel
newbadchan = goodchans(find(chanpass(goodchans) > critchan)); %  a new list of bad channels

badchans = [badchans newbadchan];% update the list of bad channels 
goodchans = setdiff(1:nChans,badchans); % update the list of good channels

artifact.goodchans = goodchans;
artifact.goodepochs = goodepochs;
artifact.editmatrix = trialdatamax;
artifact.threshhold = threshold;
artifact.zerochans = zerochans;

%% Re reference
% This function pass filtered_data and get back average referenced data.
[reRef_data] = reRef(filtered_data,goodchans);
% erpdata = mean(reRef_data(:,:,goodepochs),3); % This includes only good epochs
% plotx(erpdata(:,goodchans));% plot only the good channels

%% power spetra and coorelation
fs=2000; maxfreq=50;
[pow,freqs,df,eppow,corr,cprod,fcoef] = allspectra(reRef_data,fs,maxfreq,goodepochs);

%% make animated GIF of coor
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'coor.gif';
for i=1:length(freqs)%i=2
    % Draw plot for y = x.^n
    imagesc(squeeze(abs(corr(i,:,:)).^2));
    title(['corr in freq ' num2str(freqs(i)) ' Hz']);xlabel('chan');ylabel('chan');colorbar;
    drawnow 
      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if i == 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
end

%% make animated GIF of pow
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
filename = 'powerspetra.gif';

for i=1:length(goodchans)
    % Draw plot for y = x.^n
    plot(freqs,pow(:,goodchans(i)));
    title(['power spetrum of channel' num2str(goodchans(i))]);xlabel('freq');ylabel('power')
    
    drawnow 
      % Capture the plot as an image 
      frame = getframe(h); 
      im = frame2im(frame); 
      [imind,cm] = rgb2ind(im,256); 
      % Write to the GIF File 
      if i == 1 
          imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
      else 
          imwrite(imind,cm,filename,'gif','WriteMode','append'); 
      end 
end

%% Find returnning time point of return

%% Calculate angular position

%% Apply surface laplacian (using matnlap function)



%% using laplacian_perrinX
chanlocs=EEG.chanlocs; 
chanlocs=chanlocs(1:128); % my copy

% load('chanlocs.mat')
% chanlocs=chanlocs(1:128);% modified to the official chanlocs



X = [chanlocs.X];
Y = [chanlocs.Y];
Z = [chanlocs.Z];
%plot3(X,Y,Z,'bo')
% 
% load('chanlocs128.mat')
% X = [chanlocs128.X];
% Y = [chanlocs128.Y];
% Z = [chanlocs128.Z];
% %plot3(X,Y,Z,'bo')


% data to use is all channels in trial 1
data1=data_trials(1000,1:128,1);
data1tranpose=data1';


% apply laplacian_perrinx
n=10;
[surf_lap,G,H] = laplacian_perrinX(data1tranpose,X,Y,Z,n,1e-5);

% plot the 1000th time point
subplot(1,2,1);
topoplot(data1tranpose,chanlocs);
title('Original Data');
colorbar;
% set(gca,'clim',[-10 10]);

subplot(1,2,2);
topoplot(surf_lap,chanlocs);
title('Surface Laplacian');
colorbar;
% set(gca,'clim',[-200 0]);

% https://mikexcohen.com/lecturelets/
% http://mikexcohen.com/lecturelets/laplacian/laplacian.html

%% Computer the cross-correlation function.  Find the latency and value of the peak of the cross-correlation function.
% The cross correlation function is the correlation between the channels as a function of lag.   
% Matlab function is xcorr
% If one channel feeds the signal to the other channel with delay then the cross correlation function will be maximum with a delay. That is what I mean by latency
% Peak is the size of xcorr sometimes you can normalize that like a correlation coefficie t




%% Repeat 2-3 band-pass filtered into different bands, using an elliptical filter. 
% stop band 0.5 Hz outside of pass band, and 100 db fall off, 0.02 ripple.
% elliptic filters (designed using \textit{fdesign.bandpass} function in MATLAB) with stop band set to 0.5 Hz below and above pass band, 
% stopband attenuation set to 100 dB, and passband ripple set to 0.02. 

% Bandpass filtering was then done using the \textit{filtfilthd} function in MATLAB to minimize phase distortion. 
% We analyzed five frequency bands: delta (1-3 Hz), theta (4-7 Hz), alpha (8-13 Hz), beta (14-29 Hz) and gamma (30-80 Hz).

%% GIF of Xcorr from trial 1 to 50
h = figure;
axis tight manual % this ensures that getframe() returns a consistent size
titlename='Xcoor-beta';
filename = [titlename '.gif'];

for i=1:50 % trial number
    C3EEG=reRef_data(:,28,i);
    C4EEG=reRef_data(:,32,i);

    [r,lags]=xcorr(C3EEG, C4EEG);
    plot(lags./2,r);xlabel('time [ms]');ylabel('cross correlation');xlim([-250 250]);%ylim([-2*1e8 2*1e8]);
    title(titlename);

    drawnow 
    % Capture the plot as an image 
    frame = getframe(h); 
    im = frame2im(frame); 
    [imind,cm] = rgb2ind(im,256); 
    % Write to the GIF File 
    if i == 1 
      imwrite(imind,cm,filename,'gif', 'Loopcount',inf); 
    else 
      imwrite(imind,cm,filename,'gif','WriteMode','append'); 
    end 

end

% average 
rAll=[];

for i=1:50 % trial number
    C3EEG=reRef_data(:,28,i);
    C4EEG=reRef_data(:,32,i);

    [r,lags]=xcorr(C3EEG, C4EEG);
    rAll=[rAll r];
 
end
rAllmean=mean(rAll,2);
plot(lags./2,rAllmean);xlabel('time [ms]');ylabel('cross correlation');xlim([-250 250]);%ylim([-2*1e8 2*1e8]);
title(['mean ' titlename]);
